LD_PRELOAD=/roms/st/libst-preload.so /roms/st/st
