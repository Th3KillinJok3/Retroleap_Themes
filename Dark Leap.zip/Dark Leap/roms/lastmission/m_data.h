extern unsigned char BgMap01[9][21];
extern unsigned char LOGO[];
extern unsigned char STATUSBAR1[7][43];
extern unsigned char *SCREENS[92];
extern unsigned char *PATTERNS[118];
extern unsigned char *SCREENINFOS[92];
