extern unsigned char Font256[88*64];
extern unsigned char Tiles256[256*64];
extern unsigned char *pBgSprites[10];
extern unsigned char **pSprites256[46];
