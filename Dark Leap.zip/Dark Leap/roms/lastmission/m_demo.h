/*

	Demo mode :)

*/
void RecordDemo();
void ResetDemo();
int PlayDemo();
