/*
	Here the data for sound and music will be placed
*/
extern unsigned char rad_sndfx1[];
extern unsigned char rad_sndfx2[];
extern unsigned char rad_tune[4711];
