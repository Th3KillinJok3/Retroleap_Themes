extern unsigned char splash_screen[16384];
