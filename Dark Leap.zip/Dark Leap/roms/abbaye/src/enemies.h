/* enemies.h */

#pragma once

#include "base.h"
#include "structs.h"
